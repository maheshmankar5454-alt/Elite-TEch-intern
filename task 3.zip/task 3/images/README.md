# PWA Icons Directory

This directory should contain the PWA icons referenced in the `manifest.json` file.

## Required Icons

The following icons are referenced in the manifest and should be added to this directory:

### Main App Icons
- `icon-72x72.png` - 72x72 pixels
- `icon-96x96.png` - 96x96 pixels  
- `icon-128x128.png` - 128x128 pixels
- `icon-144x144.png` - 144x144 pixels
- `icon-152x152.png` - 152x152 pixels
- `icon-192x192.png` - 192x192 pixels
- `icon-384x384.png` - 384x384 pixels
- `icon-512x512.png` - 512x512 pixels

### Favicon Icons
- `favicon-16x16.png` - 16x16 pixels
- `favicon-32x32.png` - 32x32 pixels

### Apple Touch Icon
- `apple-touch-icon.png` - 180x180 pixels

### Shortcut Icons
- `cart-icon-96x96.png` - 96x96 pixels
- `products-icon-96x96.png` - 96x96 pixels

### Notification Icons
- `badge-72x72.png` - 72x72 pixels
- `checkmark.png` - 24x24 pixels
- `xmark.png` - 24x24 pixels

### Screenshots (Optional)
- `screenshot-wide.png` - 1280x720 pixels
- `screenshot-narrow.png` - 750x1334 pixels

## Icon Requirements

- **Format**: PNG with transparency
- **Purpose**: Should include both "any" and "maskable" purposes
- **Design**: Should be recognizable at small sizes
- **Colors**: Should work well with the app's theme color (#2563eb)

## Quick Setup

For development, you can:

1. **Use a placeholder service** like [PWA Builder](https://www.pwabuilder.com/imageGenerator)
2. **Create simple icons** using online tools like Canva or Figma
3. **Use emoji-based icons** converted to PNG format
4. **Generate from a logo** using tools like [Favicon Generator](https://realfavicongenerator.net/)

## Example Icon Generation

You can create a simple icon using CSS and convert it to PNG:

```html
<!-- Create a 512x512 div with your icon design -->
<div style="width: 512px; height: 512px; background: #2563eb; border-radius: 20%; display: flex; align-items: center; justify-content: center; color: white; font-size: 200px;">
    🛍️
</div>
```

## Testing Icons

After adding icons:

1. Clear browser cache
2. Reload the PWA
3. Check the manifest in DevTools
4. Test installation on different devices
5. Verify icons appear correctly in app launchers

## Notes

- Icons are cached by the service worker
- Update the cache version in `sw.js` when changing icons
- Test on both light and dark themes
- Ensure icons are accessible and meet contrast requirements 