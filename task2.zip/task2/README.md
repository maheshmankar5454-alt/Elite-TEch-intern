# Personal Portfolio Website

A modern, responsive personal portfolio website built with HTML, CSS, and JavaScript, featuring smooth animations powered by GSAP (GreenSock Animation Platform).

## 🚀 Features

### Visual Design
- **Modern UI/UX**: Clean, professional design with gradient backgrounds and smooth transitions
- **Responsive Layout**: Fully responsive design that works on all devices
- **Glass Morphism**: Modern glassmorphism effects in navigation and cards
- **Gradient Accents**: Beautiful gradient color schemes throughout the site

### Animations & Interactions
- **GSAP Animations**: Smooth scroll-triggered animations using GSAP ScrollTrigger
- **Hero Section**: Animated title with typing effect and floating elements
- **Parallax Effects**: Subtle parallax scrolling for enhanced depth
- **Hover Effects**: Interactive hover animations on buttons, cards, and links
- **Loading Animations**: Smooth page load transitions

### Sections
1. **Hero Section**: Eye-catching introduction with animated elements
2. **About Section**: Personal information with animated statistics
3. **Projects Section**: Showcase of featured projects with hover effects
4. **Skills Section**: Animated skill bars showing proficiency levels
5. **Contact Section**: Contact form with social media links

### Technical Features
- **Mobile Navigation**: Hamburger menu for mobile devices
- **Smooth Scrolling**: Smooth navigation between sections
- **Form Validation**: Contact form with client-side validation
- **Performance Optimized**: Efficient animations and minimal reflows

## 🛠️ Technologies Used

- **HTML5**: Semantic markup structure
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Interactive functionality
- **GSAP**: Professional animation library
- **Font Awesome**: Icon library
- **Google Fonts**: Inter font family

## 📁 File Structure

```
portfolio/
├── index.html          # Main HTML file
├── styles.css          # CSS styles and animations
├── script.js           # JavaScript functionality
└── README.md           # Documentation
```

## 🚀 Getting Started

### Prerequisites
- A modern web browser
- Basic knowledge of HTML, CSS, and JavaScript (for customization)

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. The website should load with all animations and functionality

### Local Development
For local development, you can use any local server:

```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (if you have http-server installed)
npx http-server

# Using PHP
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

## 🎨 Customization

### Personal Information
Update the following in `index.html`:
- Name and title in the hero section
- About section content
- Project details and links
- Contact information
- Social media links

### Colors and Styling
Modify the CSS variables and gradient colors in `styles.css`:
- Primary colors: `#6366f1`, `#8b5cf6`
- Accent colors: `#fbbf24`, `#f59e0b`
- Background gradients and theme colors

### Animations
Customize animations in `script.js`:
- Animation timing and easing
- Scroll trigger points
- Hover effects
- Parallax intensity

### Skills and Projects
- Add/remove skill categories and items
- Update skill percentages
- Add new project cards
- Modify project descriptions and technologies

## 📱 Responsive Design

The website is fully responsive and includes:
- Mobile-first approach
- Breakpoints for tablets and desktops
- Touch-friendly navigation
- Optimized layouts for all screen sizes

## 🌟 Animation Features

### GSAP Animations
- **ScrollTrigger**: Animations triggered by scroll position
- **Timeline**: Coordinated animation sequences
- **Stagger**: Sequential element animations
- **Easing**: Smooth animation curves

### CSS Animations
- **Keyframes**: Custom animation sequences
- **Transitions**: Smooth state changes
- **Transforms**: Scale, rotate, and translate effects

## 🔧 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Feel free to contribute to this project by:
- Reporting bugs
- Suggesting new features
- Submitting pull requests
- Improving documentation

## 📞 Support

If you have any questions or need help with customization, please:
1. Check the documentation
2. Review the code comments
3. Open an issue on the project repository

## 🎯 Performance Tips

- Optimize images before adding them
- Minimize JavaScript bundle size
- Use efficient CSS selectors
- Implement lazy loading for images
- Consider using a CDN for external libraries

## 🔮 Future Enhancements

Potential improvements for the portfolio:
- Dark/Light theme toggle
- Blog section integration
- Portfolio filtering system
- Advanced contact form with backend
- Analytics integration
- SEO optimization
- PWA capabilities

---

**Built with ❤️ using modern web technologies** 