// PWA Configuration
const APP_NAME = 'ShopPWA';
const CACHE_NAME = 'shoppwa-v1';
const CACHE_URLS = [
    '/',
    '/index.html',
    '/styles.css',
    '/app.js',
    '/sw.js',
    '/manifest.json',
    '/offline.html',
    '/products/data.json'
];

// DOM Elements
const elements = {
    productsGrid: document.getElementById('productsGrid'),
    cartBtn: document.getElementById('cartBtn'),
    cartCount: document.getElementById('cartCount'),
    cartModal: document.getElementById('cartModal'),
    cartItems: document.getElementById('cartItems'),
    cartTotal: document.getElementById('cartTotal'),
    closeCart: document.getElementById('closeCart'),
    checkoutBtn: document.getElementById('checkoutBtn'),
    installBtn: document.getElementById('installBtn'),
    installBanner: document.getElementById('installBanner'),
    bannerInstallBtn: document.getElementById('bannerInstallBtn'),
    dismissBanner: document.getElementById('dismissBanner'),
    offlineStatus: document.getElementById('offlineStatus'),
    toast: document.getElementById('toast')
};

// App State
let products = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let deferredPrompt = null;

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

// Main initialization function
async function initializeApp() {
    try {
        // Register service worker
        await registerServiceWorker();
        
        // Load products
        await loadProducts();
        
        // Setup event listeners
        setupEventListeners();
        
        // Setup PWA features
        setupPWAFeatures();
        
        // Update cart display
        updateCartDisplay();
        
        // Check online status
        updateOnlineStatus();
        
        console.log('ShopPWA initialized successfully');
    } catch (error) {
        console.error('Failed to initialize app:', error);
        showToast('Failed to load app. Please refresh the page.', 'error');
    }
}

// Service Worker Registration
async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/sw.js');
            console.log('Service Worker registered:', registration);
            
            // Listen for service worker updates
            registration.addEventListener('updatefound', () => {
                const newWorker = registration.installing;
                newWorker.addEventListener('statechange', () => {
                    if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                        showToast('New version available! Refresh to update.', 'info');
                    }
                });
            });
            
            return registration;
        } catch (error) {
            console.error('Service Worker registration failed:', error);
            throw error;
        }
    } else {
        console.warn('Service Worker not supported');
    }
}

// Load Products
async function loadProducts() {
    try {
        const response = await fetch('/products/data.json');
        if (!response.ok) {
            throw new Error('Failed to fetch products');
        }
        
        products = await response.json();
        renderProducts();
    } catch (error) {
        console.error('Error loading products:', error);
        elements.productsGrid.innerHTML = `
            <div class="error-message">
                <p>Failed to load products. Please check your connection and try again.</p>
                <button onclick="loadProducts()" class="retry-btn">Retry</button>
            </div>
        `;
    }
}

// Render Products
function renderProducts() {
    if (!products.length) {
        elements.productsGrid.innerHTML = '<div class="no-products">No products available</div>';
        return;
    }
    
    const productsHTML = products.map(product => `
        <div class="product-card" data-product-id="${product.id}">
            <div class="product-image">
                ${product.image ? `<img src="${product.image}" alt="${product.name}" loading="lazy">` : '📦'}
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-price">$${product.price.toFixed(2)}</div>
                <button class="add-to-cart-btn" onclick="addToCart(${product.id})">
                    Add to Cart
                </button>
            </div>
        </div>
    `).join('');
    
    elements.productsGrid.innerHTML = productsHTML;
}

// Cart Functions
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }
    
    saveCart();
    updateCartDisplay();
    showToast(`${product.name} added to cart!`, 'success');
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartDisplay();
    showToast('Item removed from cart', 'info');
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (!item) return;
    
    item.quantity += change;
    
    if (item.quantity <= 0) {
        removeFromCart(productId);
    } else {
        saveCart();
        updateCartDisplay();
    }
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartDisplay() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    elements.cartCount.textContent = totalItems;
    elements.cartTotal.textContent = totalPrice.toFixed(2);
    
    renderCartItems();
}

function renderCartItems() {
    if (cart.length === 0) {
        elements.cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
        return;
    }
    
    const cartHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-image">
                ${item.image ? `<img src="${item.image}" alt="${item.name}">` : '📦'}
            </div>
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">$${item.price.toFixed(2)}</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
            </div>
            <button class="remove-item-btn" onclick="removeFromCart(${item.id})">Remove</button>
        </div>
    `).join('');
    
    elements.cartItems.innerHTML = cartHTML;
}

// Event Listeners
function setupEventListeners() {
    // Cart modal
    elements.cartBtn.addEventListener('click', () => {
        elements.cartModal.style.display = 'block';
    });
    
    elements.closeCart.addEventListener('click', () => {
        elements.cartModal.style.display = 'none';
    });
    
    elements.cartModal.addEventListener('click', (e) => {
        if (e.target === elements.cartModal) {
            elements.cartModal.style.display = 'none';
        }
    });
    
    // Checkout
    elements.checkoutBtn.addEventListener('click', () => {
        if (cart.length === 0) {
            showToast('Your cart is empty!', 'error');
            return;
        }
        showToast('Checkout functionality would be implemented here!', 'info');
    });
    
    // Install banner
    elements.dismissBanner.addEventListener('click', () => {
        elements.installBanner.style.display = 'none';
        localStorage.setItem('installBannerDismissed', 'true');
    });
    
    // Online/offline status
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
}

// PWA Features
function setupPWAFeatures() {
    // Install prompt
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        
        // Show install button if not already installed
        if (!isAppInstalled()) {
            elements.installBtn.style.display = 'inline-block';
            elements.installBtn.addEventListener('click', installApp);
        }
        
        // Show install banner
        if (!localStorage.getItem('installBannerDismissed')) {
            setTimeout(() => {
                elements.installBanner.style.display = 'block';
            }, 3000);
        }
    });
    
    // App installed event
    window.addEventListener('appinstalled', () => {
        console.log('App installed successfully');
        elements.installBtn.style.display = 'none';
        elements.installBanner.style.display = 'none';
        showToast('App installed successfully!', 'success');
    });
    
    // Push notification setup (dummy implementation)
    setupPushNotifications();
}

function installApp() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the install prompt');
            } else {
                console.log('User dismissed the install prompt');
            }
            deferredPrompt = null;
        });
    }
}

function isAppInstalled() {
    return window.matchMedia('(display-mode: standalone)').matches ||
           window.navigator.standalone === true;
}

// Push Notifications (Dummy Implementation)
async function setupPushNotifications() {
    if ('Notification' in window && 'serviceWorker' in navigator) {
        const permission = await Notification.requestPermission();
        
        if (permission === 'granted') {
            console.log('Push notifications enabled');
            // In a real implementation, you would:
            // 1. Get the service worker registration
            // 2. Get the push subscription
            // 3. Send the subscription to your server
            // 4. Use Firebase Cloud Messaging or similar service
        }
    }
}

// Utility Functions
function updateOnlineStatus() {
    if (navigator.onLine) {
        elements.offlineStatus.style.display = 'none';
    } else {
        elements.offlineStatus.style.display = 'block';
        showToast('You are now offline', 'warning');
    }
}

function showToast(message, type = 'info') {
    const toast = elements.toast;
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && elements.cartModal.style.display === 'block') {
        elements.cartModal.style.display = 'none';
    }
});

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
        console.log(`Page load time: ${loadTime}ms`);
    });
}

// Export functions for global access
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;
window.loadProducts = loadProducts; 